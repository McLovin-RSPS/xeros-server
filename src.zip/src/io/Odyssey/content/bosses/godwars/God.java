package io.Odyssey.content.bosses.godwars;

public enum God {
	SARADOMIN,
	ZAMORAK,
	BANDOS,
	ARMADYL
}
