package io.Odyssey.content.combat.magic;

public class MagicConfig {

}