package io.Odyssey.content.commands.all;

import io.Odyssey.content.commands.Command;
import io.Odyssey.model.entity.player.Player;
import io.Odyssey.sql.NewVote;

import java.util.Optional;

public class ClaimVote extends Command {//you see this hammer ?ye click on it one time when you change anything
    @Override
    public void execute(Player player, String commandName, String input) {
        new Thread(new NewVote(player)).start();//you seen it yea i umdersyand also to end u just click the square? ye
        player.sendMessage("Checking for reward Please wait...");// wanna do a change and im watching? or no i think im good nowok



    }

    @Override
    public Optional<String> getDescription() {
        return Optional.of("Collect Vote Waiting.");
    }
}
