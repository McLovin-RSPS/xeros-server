package io.Odyssey.content.boosts;

public enum BoostType {
    EXPERIENCE, GENERIC
}
